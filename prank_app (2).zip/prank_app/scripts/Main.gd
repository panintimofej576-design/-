extends Control

# Главный скрипт сцены.
# Отвечает за:
# - бесконечное зацикливание фонового видео
# - запуск экрана "Введите код" через 5 секунд после старта

@onready var video_player: VideoStreamPlayer = $VideoPlayer
@onready var lock_screen: CanvasLayer = $LockScreen
@onready var lock_timer: Timer = $LockTimer


func _ready() -> void:
	# Подписываемся на сигналы
	video_player.finished.connect(_on_video_finished)
	lock_timer.timeout.connect(_on_lock_timer_timeout)

	# На старте окно кода скрыто
	lock_screen.visible = false

	# Явно запускаем видео и таймер (на случай если autoplay/autostart
	# не сработали на некоторых устройствах)
	if video_player.stream != null:
		video_player.play()
	lock_timer.start()


func _on_video_finished() -> void:
	# VideoStreamPlayer в Godot 4 не имеет встроенного зацикливания,
	# поэтому перезапускаем воспроизведение вручную при каждом завершении.
	video_player.play()


func _on_lock_timer_timeout() -> void:
	lock_screen.show_lock()
