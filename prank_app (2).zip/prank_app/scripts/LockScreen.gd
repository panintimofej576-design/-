extends CanvasLayer

# Полноэкранное окно "Введите код".
# Правильный код: 4564

const CORRECT_CODE: String = "4564"

@onready var panel: Panel = $Background/Panel
@onready var code_input: LineEdit = $Background/Panel/VBox/CodeInput
@onready var unlock_button: Button = $Background/Panel/VBox/UnlockButton
@onready var error_label: Label = $Background/Panel/VBox/ErrorLabel

var _panel_base_position: Vector2
var _is_shaking: bool = false


func _ready() -> void:
	visible = false
	error_label.visible = false

	unlock_button.pressed.connect(_on_unlock_pressed)
	code_input.text_submitted.connect(_on_code_submitted)


func show_lock() -> void:
	visible = true
	error_label.visible = false
	code_input.text = ""

	# Забавная анимация появления окна "выпрыгиванием"
	panel.scale = Vector2(0.05, 0.05)
	panel.pivot_offset = panel.size / 2.0
	_panel_base_position = panel.position

	var tween: Tween = create_tween()
	tween.set_trans(Tween.TRANS_BACK)
	tween.set_ease(Tween.EASE_OUT)
	tween.tween_property(panel, "scale", Vector2.ONE, 0.45)

	code_input.grab_focus()


func _on_unlock_pressed() -> void:
	_check_code()


func _on_code_submitted(_text: String) -> void:
	_check_code()


func _check_code() -> void:
	if _is_shaking:
		return

	if code_input.text.strip_edges() == CORRECT_CODE:
		_unlock()
	else:
		_show_error()


func _unlock() -> void:
	var tween: Tween = create_tween()
	tween.set_trans(Tween.TRANS_BACK)
	tween.set_ease(Tween.EASE_IN)
	tween.tween_property(panel, "scale", Vector2(0.05, 0.05), 0.3)
	tween.tween_callback(func() -> void:
		visible = false
		code_input.text = ""
	)


func _show_error() -> void:
	error_label.visible = true
	code_input.text = ""
	_is_shaking = true

	var tween: Tween = create_tween()
	tween.tween_property(panel, "position", _panel_base_position + Vector2(18, 0), 0.05)
	tween.tween_property(panel, "position", _panel_base_position - Vector2(18, 0), 0.05)
	tween.tween_property(panel, "position", _panel_base_position + Vector2(10, 0), 0.05)
	tween.tween_property(panel, "position", _panel_base_position, 0.05)
	tween.tween_callback(func() -> void:
		_is_shaking = false
		code_input.grab_focus()
	)
