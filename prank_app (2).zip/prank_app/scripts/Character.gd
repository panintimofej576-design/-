extends Node2D

# Скрипт заставляет персонажа летать по экрану случайной траекторией
# и отскакивать от краёв экрана, как логотип DVD.

@export var min_speed: float = 100.0
@export var max_speed: float = 220.0
@export var rotate_while_moving: bool = true
@export var bob_amplitude: float = 6.0   # лёгкое "подпрыгивание" для смеха
@export var bob_speed: float = 6.0

var velocity: Vector2
var screen_size: Vector2
var time_passed: float = 0.0


func _ready() -> void:
	randomize()
	screen_size = get_viewport_rect().size

	var angle: float = randf_range(0.0, TAU)
	var speed: float = randf_range(min_speed, max_speed)
	velocity = Vector2(cos(angle), sin(angle)) * speed

	# Случайная стартовая позиция, если не задана вручную в сцене
	if position == Vector2.ZERO:
		position = Vector2(
			randf_range(0.0, screen_size.x),
			randf_range(0.0, screen_size.y)
		)


func _process(delta: float) -> void:
	time_passed += delta
	position += velocity * delta

	# Отскок от границ экрана
	if position.x < 0.0:
		position.x = 0.0
		velocity.x *= -1.0
	elif position.x > screen_size.x:
		position.x = screen_size.x
		velocity.x *= -1.0

	if position.y < 0.0:
		position.y = 0.0
		velocity.y *= -1.0
	elif position.y > screen_size.y:
		position.y = screen_size.y
		velocity.y *= -1.0

	if rotate_while_moving:
		rotation = velocity.angle()

	# Небольшое пружинящее покачивание масштаба — забавный эффект
	var bob: float = 1.0 + sin(time_passed * bob_speed) * 0.05
	scale = Vector2(bob, bob)
